#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>

int make_fifo(const char *path)
{
    int ret = mkfifo(path, 0777);
    if (ret == -1)
    {
        printf("make fifo %s error\n", path);
        return -1;
    }
    printf("make fifo %s success\n", path);
}

int main()
{
    char fifo_A_to_B[] = "./fifo_ab";
    char fifo_B_to_A[] = "./fifo_ba";

    int ret;
    ret = make_fifo(fifo_A_to_B);
    if (ret == -1)
    {
        return -1;
    }
    ret = make_fifo(fifo_B_to_A);
    if (ret == -1)
    {
        return -1;
    }
    return 0;
}