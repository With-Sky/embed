#include "stdio.h"
#include "string.h"
#include "fcntl.h"
#include "unistd.h"
void str_clr(char *s, int len)
{
    int i = 0;
    for (; i < len; i++)
    {
        s[i] = '\0';
    }
}

void receive(int fd)
{
    char buf[128] = {0};
    int len = 0;
    while (1)
    {
        len = read(fd, buf, 128);
        printf("received: %s\n", buf);
        str_clr(buf, len);
    }
}

void send(int fd)
{
    char buf[128] = {0};
    int len = 0, i = 0;
    while (1)
    {
        printf("please input a string\n");
        scanf("%s", buf);
        len = strlen(buf);
        write(fd, buf, len);
        str_clr(buf, len);
    }
}

int open_fifo_receive(const char *path)
{
    int fd = open(path, O_RDONLY, 0777);
    if (fd == -1)
    {
        printf("open %s error\n", path);
        return -1;
    }
    printf("open %s success\n", path);
    return fd;
}
int open_fifo_send(const char *path)
{
    int fd = open(path, O_WRONLY, 0777);
    if (fd == -1)
    {
        printf("open %s error\n", path);
        return -1;
    }
    printf("open %s success\n", path);
    return fd;
}
int main()
{
    char receive_fifo[] = "./fifo_ab";
    char send_fifo[] = "./fifo_ba";
    int fd_receive, fd_send;
    pid_t pid;
    fd_receive = open_fifo_receive(receive_fifo);
    if (fd_receive < 0)
    {
        return -1;
    }
    fd_send = open_fifo_send(send_fifo);
    if (fd_send < 0)
    {
        return -1;
    }
    pid = fork();
    if (pid > 0)
    {
        send(fd_send);
    }
    else if (pid == 0)
    {
        printf("receiving...\n");
        receive(fd_receive);
    }
    else
    {
        printf("fork error\n");
    }
    return 0;
}