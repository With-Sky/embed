#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

ssize_t get_file_size(int fd)
{
    ssize_t f_size = lseek(fd, 0, SEEK_END);
    lseek(fd, 0, SEEK_SET);
    return f_size;
}

int main(int arg_count, char **args)
{
    if (arg_count != 3)
    {
        printf("Error usage\n");
        return -1;
    }
    int in_fd = 0, out_fd = 0;
    char *in_file = args[1], *out_file = args[2], *buffer = NULL;
    ssize_t in_size = 0, read_len = 0, write_len = 0;
    in_fd = open(in_file, O_RDONLY);
    if (in_fd < 0)
    {
        printf("Open file %s fail\n", in_file);
        return -1;
    }
    out_fd = open(out_file, O_CREAT | O_RDWR | O_TRUNC, 0777);
    if (out_fd < 0)
    {
        printf("Create file %s fail\n", out_file);
        return -1;
    }
    in_size = get_file_size(in_fd);
    if (in_size < 0)
    {
        printf("Get file %s size error\n", in_file);
        close(in_fd);
        close(out_fd);
        return -1;
    }
    buffer = calloc(in_size + 1, sizeof(char));
    read_len = read(in_fd, buffer, in_size);
    if (read_len < 0)
    {
        printf("Read file %s error\n", in_file);
        close(in_fd);
        close(out_fd);
        return -1;
    }
    write_len = write(out_fd, buffer, in_size);
    if (write_len < 0)
    {
        printf("Write file %s error\n", out_file);
        close(in_fd);
        close(out_fd);
        return -1;
    }
    printf("Copy success,file size: %ld byte\n", in_size);
    free(buffer);
    close(in_fd);
    close(out_fd);
    return 0;
}